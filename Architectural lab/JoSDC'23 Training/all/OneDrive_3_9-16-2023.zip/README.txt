For this lab, you DO NOT need to submit any Verilog code or any other documents. You only need to implement the requested parts as in "Lab2_BCD_adder-PartIV" video and check your code. If you have any questions or issues while working on this lab, please let me know.

If you don't have access to an FPGA board, you still can finish the Verilog code and compile it. We will learn about simulation later. 

